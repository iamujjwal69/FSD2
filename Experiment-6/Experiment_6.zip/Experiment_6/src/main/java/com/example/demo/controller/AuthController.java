package com.example.demo.controller;

import com.example.demo.security.JwtUtil;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
public class AuthController {

    JwtUtil jwtUtil = new JwtUtil();

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> user) {

        String username = user.get("username");
        String password = user.get("password");

        if (username.equals("user123") && password.equals("password123")) {

            String token = jwtUtil.generateToken(username);

            Map<String, String> response = new HashMap<>();
            response.put("token", token);

            return response;
        }

        throw new RuntimeException("Invalid Credentials");
    }

    @GetMapping("/protected")
    public String protectedRoute(@RequestHeader("Authorization") String header) {

        String token = header.replace("Bearer ", "");

        if (jwtUtil.validateToken(token)) {
            return "Access Granted 🔥";
        }

        throw new RuntimeException("Invalid Token ❌");
    }
}